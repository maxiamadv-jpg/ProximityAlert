package com.proximityalert.phone

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.proximityalert.phone.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isMonitoring = false

    companion object {
        private const val TAG = "ProximityAlert"
        private const val REQUEST_PERMISSIONS = 100
    }

    private val requiredPermissions = buildList {
        add(Manifest.permission.BLUETOOTH_CONNECT)
        add(Manifest.permission.BLUETOOTH_SCAN)
        add(Manifest.permission.BLUETOOTH_ADVERTISE)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        checkBluetoothSupport()
    }

    private fun setupUI() {
        binding.btnToggle.setOnClickListener {
            if (isMonitoring) stopMonitoring() else checkPermissionsAndStart()
        }

        binding.sliderThreshold.addOnChangeListener { _, value, _ ->
            binding.tvThresholdValue.text = String.format("%.1f m", value)
            // Aggiorna soglia nel servizio
            val intent = Intent(this, ProximityService::class.java).apply {
                action = ProximityService.ACTION_UPDATE_THRESHOLD
                putExtra(ProximityService.EXTRA_THRESHOLD, value)
            }
            startService(intent)
        }

        // Valore iniziale slider
        binding.tvThresholdValue.text = "2.0 m"
    }

    private fun checkBluetoothSupport() {
        val bm = getSystemService(BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = bm?.adapter
        if (adapter == null) {
            binding.tvStatus.text = "Bluetooth non supportato su questo dispositivo"
            binding.btnToggle.isEnabled = false
            return
        }
        if (!adapter.isEnabled) {
            binding.tvStatus.text = "Attiva il Bluetooth per continuare"
            binding.tvStatusIcon.text = "📶"
        }
    }

    private fun checkPermissionsAndStart() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            startMonitoring()
        } else {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_PERMISSIONS)
        }
    }

    private fun startMonitoring() {
        isMonitoring = true
        updateUI(true)

        val serviceIntent = Intent(this, ProximityService::class.java).apply {
            action = ProximityService.ACTION_START
            putExtra(ProximityService.EXTRA_THRESHOLD, binding.sliderThreshold.value)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        Toast.makeText(this, "Monitoraggio avviato", Toast.LENGTH_SHORT).show()
    }

    private fun stopMonitoring() {
        isMonitoring = false
        updateUI(false)

        val serviceIntent = Intent(this, ProximityService::class.java).apply {
            action = ProximityService.ACTION_STOP
        }
        startService(serviceIntent)
        Toast.makeText(this, "Monitoraggio fermato", Toast.LENGTH_SHORT).show()
    }

    private fun updateUI(active: Boolean) {
        if (active) {
            binding.btnToggle.text = "⏹ Ferma Monitoraggio"
            binding.btnToggle.setBackgroundColor(
                ContextCompat.getColor(this, R.color.color_stop))
            binding.tvStatus.text = "Monitoraggio attivo\nSmartwatch collegato"
            binding.tvStatusIcon.text = "🔗"
            binding.cardStatus.setCardBackgroundColor(
                ContextCompat.getColor(this, R.color.color_active_bg))
            binding.progressPulse.visibility = View.VISIBLE
        } else {
            binding.btnToggle.text = "▶ Avvia Monitoraggio"
            binding.btnToggle.setBackgroundColor(
                ContextCompat.getColor(this, R.color.color_start))
            binding.tvStatus.text = "Monitoraggio inattivo"
            binding.tvStatusIcon.text = "📵"
            binding.cardStatus.setCardBackgroundColor(
                ContextCompat.getColor(this, R.color.color_inactive_bg))
            binding.progressPulse.visibility = View.GONE
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                startMonitoring()
            } else {
                Toast.makeText(
                    this,
                    "Permessi necessari non concessi. Abilitali nelle Impostazioni.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Non fermiamo il servizio alla chiusura dell'activity (gira in background)
    }
}
