package com.proximityalert.phone

import android.app.*
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Intent
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.android.gms.wearable.*
import kotlinx.coroutines.*
import kotlin.math.pow

/**
 * Foreground Service che:
 *  1. Scansiona continuamente il BLE RSSI dello smartwatch accoppiato
 *  2. Stima la distanza tramite la formula RSSI → distanza
 *  3. Invia un messaggio via Wearable Data Layer quando si supera la soglia
 */
class ProximityService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP  = "ACTION_STOP"
        const val ACTION_UPDATE_THRESHOLD = "ACTION_UPDATE_THRESHOLD"
        const val EXTRA_THRESHOLD = "threshold"

        private const val TAG = "ProximityService"
        private const val CHANNEL_ID = "proximity_channel"
        private const val NOTIF_ID = 1

        // Percorso messaggio Wearable Data Layer
        const val WEAR_PATH_ALERT = "/alert"
        const val WEAR_PATH_STATUS = "/status"

        // Parametri stima distanza BLE
        // TX_POWER: potenza di trasmissione a 1 metro (dBm) — valore tipico Wear OS
        private const val TX_POWER = -59.0
        // N: fattore ambientale (2.0 = spazio aperto, 3.0-4.0 = ambienti interni)
        private const val PATH_LOSS_EXP = 2.5
    }

    private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var scanJob: Job? = null

    private lateinit var bluetoothLeScanner: BluetoothLeScanner
    private var thresholdMeters = 2.0f
    private var lastAlertState = false  // true = oltre soglia

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val bm = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothLeScanner = bm.adapter.bluetoothLeScanner
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                thresholdMeters = intent.getFloatExtra(EXTRA_THRESHOLD, 2.0f)
                startForeground(NOTIF_ID, buildNotification("Monitoraggio attivo…"))
                startScanning()
            }
            ACTION_STOP -> {
                stopScanning()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_UPDATE_THRESHOLD -> {
                thresholdMeters = intent.getFloatExtra(EXTRA_THRESHOLD, 2.0f)
                Log.d(TAG, "Soglia aggiornata: ${thresholdMeters}m")
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopScanning()
        coroutineScope.cancel()
    }

    // ---------------------------------------------------------------
    // BLE Scanning
    // ---------------------------------------------------------------

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            handleScanResult(result)
        }

        override fun onBatchScanResults(results: List<ScanResult>) {
            results.forEach { handleScanResult(it) }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "Scansione BLE fallita: $errorCode")
        }
    }

    private fun startScanning() {
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0)
            .build()

        // Scansiona tutti i dispositivi accoppiati (filtra lato callback)
        try {
            bluetoothLeScanner.startScan(null, settings, scanCallback)
            Log.d(TAG, "Scansione BLE avviata")
        } catch (e: SecurityException) {
            Log.e(TAG, "Permesso Bluetooth mancante: ${e.message}")
        }

        // Heartbeat ogni 30s: invia stato al watch
        scanJob = coroutineScope.launch {
            while (isActive) {
                delay(30_000)
                sendWearMessage(WEAR_PATH_STATUS, "ALIVE")
            }
        }
    }

    private fun stopScanning() {
        scanJob?.cancel()
        try {
            bluetoothLeScanner.stopScan(scanCallback)
        } catch (e: SecurityException) {
            Log.e(TAG, "Errore stop scan: ${e.message}")
        }
    }

    // ---------------------------------------------------------------
    // Logica distanza
    // ---------------------------------------------------------------

    private fun handleScanResult(result: ScanResult) {
        // Considera solo dispositivi Wear OS accoppiati
        val pairedDevices = try {
            (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager)
                .adapter.bondedDevices
        } catch (e: SecurityException) { emptySet() }

        val device = pairedDevices.find { it.address == result.device.address } ?: return

        val rssi = result.rssi
        val distanceMeters = estimateDistance(rssi)

        Log.d(TAG, "Dispositivo: ${device.address} | RSSI: $rssi dBm | ~${String.format("%.2f", distanceMeters)}m")

        val isToFar = distanceMeters > thresholdMeters

        if (isToFar && !lastAlertState) {
            // Appena superata la soglia → allerta
            lastAlertState = true
            Log.w(TAG, "ALLERTA: dispositivo oltre ${thresholdMeters}m (${String.format("%.2f", distanceMeters)}m)")
            sendWearMessage(WEAR_PATH_ALERT, "ALERT:${distanceMeters.toInt()}")
            updateNotification("⚠️ Distanza superata! ~${distanceMeters.toInt()}m")
        } else if (!isToFar && lastAlertState) {
            // Rientrato nel range → annulla allerta
            lastAlertState = false
            Log.i(TAG, "Dispositivo rientrato nel range (${String.format("%.2f", distanceMeters)}m)")
            sendWearMessage(WEAR_PATH_ALERT, "CLEAR")
            updateNotification("✅ Dispositivi vicini")
        }
    }

    /**
     * Formula standard RSSI → distanza:
     * d = 10 ^ ((TxPower - RSSI) / (10 * n))
     */
    private fun estimateDistance(rssi: Int): Double {
        return 10.0.pow((TX_POWER - rssi) / (10 * PATH_LOSS_EXP))
    }

    // ---------------------------------------------------------------
    // Wearable Data Layer
    // ---------------------------------------------------------------

    private fun sendWearMessage(path: String, message: String) {
        coroutineScope.launch {
            try {
                val nodeClient = Wearable.getNodeClient(applicationContext)
                val nodes = nodeClient.connectedNodes.await()

                if (nodes.isEmpty()) {
                    Log.w(TAG, "Nessun nodo Wear OS connesso")
                    return@launch
                }

                val messageClient = Wearable.getMessageClient(applicationContext)
                nodes.forEach { node ->
                    messageClient.sendMessage(node.id, path, message.toByteArray())
                        .await()
                    Log.d(TAG, "Messaggio '$message' inviato a ${node.displayName}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Errore invio messaggio Wear: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------------
    // Notifica Foreground
    // ---------------------------------------------------------------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Monitoraggio Prossimità",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitoraggio distanza smartphone-smartwatch"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ProximityAlert")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
