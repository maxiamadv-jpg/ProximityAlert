package com.proximityalert.phone

import android.util.Log
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * Riceve messaggi dallo smartwatch verso il telefono
 * (es. conferma ricezione allerta, richiesta stato)
 */
class WearMessageListenerService : WearableListenerService() {

    companion object {
        private const val TAG = "WearMsgListener"
    }

    override fun onMessageReceived(messageEvent: MessageEvent) {
        val msg = String(messageEvent.data)
        Log.d(TAG, "Messaggio ricevuto dallo watch [${messageEvent.path}]: $msg")

        when (messageEvent.path) {
            "/proximity" -> {
                when (msg) {
                    "ACK" -> Log.i(TAG, "Watch ha confermato ricezione allerta")
                    "REQUEST_STATUS" -> {
                        // Il watch chiede lo stato attuale — il servizio risponde
                        Log.i(TAG, "Watch richiede stato attuale")
                    }
                }
            }
        }
    }
}
