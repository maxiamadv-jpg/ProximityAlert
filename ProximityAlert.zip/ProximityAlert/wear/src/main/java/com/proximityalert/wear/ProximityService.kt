package com.proximityalert.wear

import android.app.*
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.UUID

/**
 * ProximityService – Foreground service on the smartwatch.
 *
 * Continuously scans BLE advertisements from the paired phone
 * (identified by PROXIMITY_SERVICE_UUID). If the RSSI falls below
 * RSSI_THRESHOLD (≈ 2 metres away), the watch vibrates and plays
 * an alert tone.
 *
 * RSSI → Distance approximation
 * ──────────────────────────────
 * The free-space path-loss model:  distance = 10 ^ ((TxPower - RSSI) / (10 * n))
 * where n ≈ 2.0 (open space) and TxPower ≈ -59 dBm at 1 m (typical BLE).
 *
 * For ~2 m:  RSSI ≈ -59 - 10*2*log10(2)  ≈  -65 dBm
 * We use a slightly conservative threshold of -70 dBm to reduce false positives.
 */
class ProximityService : Service() {

    companion object {
        const val TAG = "ProximityService"

        val PROXIMITY_SERVICE_UUID: UUID =
            UUID.fromString("12345678-1234-1234-1234-123456789abc")

        /**
         * RSSI threshold in dBm.
         * Values more negative than this = device is farther than ~2 m.
         * Tune between -65 and -75 depending on environment.
         */
        const val RSSI_THRESHOLD = -70

        /**
         * How many consecutive out-of-range readings before alerting.
         * Prevents false positives from RSSI jitter.
         */
        const val CONSECUTIVE_MISS_THRESHOLD = 3

        const val CHANNEL_ID = "proximity_alert_channel"
        const val NOTIF_ID   = 1

        @Volatile var isRunning = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, ProximityService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ProximityService::class.java))
        }
    }

    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private var isScanning = false

    /** Counts how many consecutive scans have returned no signal or weak signal */
    private var missedReadings = 0
    private var lastAlertTime  = 0L

    /** Minimum gap between repeated alerts (ms) */
    private val ALERT_COOLDOWN_MS = 3_000L

    private val handler = Handler(Looper.getMainLooper())

    // ─── Service lifecycle ────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Scansione attiva…"))
        isRunning = true
        startBleScan()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stopBleScan()
        isRunning = false
        Log.d(TAG, "ProximityService distrutto.")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─── BLE Scanning ─────────────────────────────────────────────────────

    private fun startBleScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter

        if (adapter == null || !adapter.isEnabled) {
            Log.w(TAG, "Bluetooth non disponibile o disabilitato.")
            stopSelf()
            return
        }

        bluetoothLeScanner = adapter.bluetoothLeScanner

        val filter = ScanFilter.Builder()
            .setServiceUuid(android.os.ParcelUuid(PROXIMITY_SERVICE_UUID))
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0)  // report immediately
            .build()

        bluetoothLeScanner?.startScan(listOf(filter), settings, scanCallback)
        isScanning = true
        Log.d(TAG, "BLE scan avviato, cercando UUID=$PROXIMITY_SERVICE_UUID")

        // Schedule periodic "no-signal" checks
        handler.postDelayed(noSignalChecker, 2_000)
    }

    private fun stopBleScan() {
        handler.removeCallbacks(noSignalChecker)
        if (isScanning) {
            bluetoothLeScanner?.stopScan(scanCallback)
            isScanning = false
        }
    }

    /**
     * Runs every 2 s. If the phone hasn't been seen recently,
     * increment the miss counter and potentially trigger the alert.
     */
    private var phoneSeenInWindow = false

    private val noSignalChecker = object : Runnable {
        override fun run() {
            if (!phoneSeenInWindow) {
                missedReadings++
                Log.d(TAG, "Telefono non rilevato — misses: $missedReadings")
                if (missedReadings >= CONSECUTIVE_MISS_THRESHOLD) {
                    triggerAlert(reason = "Fuori portata")
                }
            } else {
                // Phone detected — reset counter
                missedReadings = 0
                updateNotification("📶  Telefono vicino")
            }
            phoneSeenInWindow = false
            if (isRunning) handler.postDelayed(this, 2_000)
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val rssi = result.rssi
            Log.d(TAG, "Telefono rilevato — RSSI: $rssi dBm")

            phoneSeenInWindow = true

            if (rssi < RSSI_THRESHOLD) {
                missedReadings++
                Log.d(TAG, "RSSI sotto soglia ($rssi < $RSSI_THRESHOLD) — misses: $missedReadings")
                if (missedReadings >= CONSECUTIVE_MISS_THRESHOLD) {
                    triggerAlert(reason = "Distanza >2 m (RSSI $rssi dBm)")
                }
            } else {
                missedReadings = 0
                updateNotification("📶  Telefono vicino ($rssi dBm)")
            }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "BLE scan fallito: $errorCode")
        }
    }

    // ─── Alert (vibration + sound) ────────────────────────────────────────

    private fun triggerAlert(reason: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastAlertTime < ALERT_COOLDOWN_MS) return  // Rispetta il cooldown
        lastAlertTime = now
        missedReadings = 0

        Log.d(TAG, "🔔 ALERT: $reason")
        updateNotification("⚠️  Troppo lontano!")

        vibrate()
        playAlertSound()
    }

    private fun vibrate() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        // Pattern: 0ms delay, 300ms on, 150ms off, 300ms on, 150ms off, 500ms on
        val pattern = longArrayOf(0, 300, 150, 300, 150, 500)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createWaveform(pattern, -1)  // -1 = no repeat
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }

    private fun playAlertSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone = RingtoneManager.getRingtone(applicationContext, uri)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ringtone.isLooping = false
            }
            ringtone.play()
        } catch (e: Exception) {
            Log.e(TAG, "Impossibile riprodurre suono: ${e.message}")
        }
    }

    // ─── Notification helpers ─────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Monitoraggio Prossimità",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Servizio di controllo distanza Bluetooth"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, WearMainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ProximityAlert")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_radar_on)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
