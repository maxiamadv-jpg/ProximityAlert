package com.proximityalert.wear

import android.os.*
import android.util.Log
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * Riceve messaggi dal telefono e attiva vibrazione/suono sullo smartwatch
 */
class WearListenerService : WearableListenerService() {

    companion object {
        private const val TAG = "WearListener"
        const val ACTION_ALERT = "com.proximityalert.wear.ACTION_ALERT"
        const val ACTION_CLEAR = "com.proximityalert.wear.ACTION_CLEAR"
        const val EXTRA_DISTANCE = "distance"
    }

    override fun onMessageReceived(messageEvent: MessageEvent) {
        val msg = String(messageEvent.data)
        Log.d(TAG, "Messaggio ricevuto dal telefono [${messageEvent.path}]: $msg")

        when (messageEvent.path) {
            "/alert" -> handleAlert(msg)
            "/status" -> Log.d(TAG, "Heartbeat ricevuto: $msg")
        }
    }

    private fun handleAlert(message: String) {
        when {
            message.startsWith("ALERT:") -> {
                val distance = message.removePrefix("ALERT:").toIntOrNull() ?: 0
                Log.w(TAG, "ALLERTA! Distanza: ~${distance}m")

                // Vibrazione a pattern SOS per allerta
                triggerVibration()

                // Aggiorna l'UI dell'activity se aperta
                val intent = android.content.Intent(ACTION_ALERT).apply {
                    putExtra(EXTRA_DISTANCE, distance)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }
            message == "CLEAR" -> {
                Log.i(TAG, "Allerta rientrata — dispositivi di nuovo vicini")
                // Vibrazione breve di conferma
                triggerShortVibration()

                val intent = android.content.Intent(ACTION_CLEAR).apply {
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }
        }
    }

    private fun triggerVibration() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Pattern: 3 vibrazioni da 300ms con pausa da 200ms
            val pattern = longArrayOf(0, 300, 200, 300, 200, 300)
            val amplitudes = intArrayOf(0, VibrationEffect.DEFAULT_AMPLITUDE,
                0, VibrationEffect.DEFAULT_AMPLITUDE,
                0, VibrationEffect.DEFAULT_AMPLITUDE)
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, amplitudes, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 300, 200, 300, 200, 300), -1)
        }
    }

    private fun triggerShortVibration() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(150)
        }
    }
}
