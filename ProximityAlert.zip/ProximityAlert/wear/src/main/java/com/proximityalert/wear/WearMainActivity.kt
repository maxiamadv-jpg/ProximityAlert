package com.proximityalert.wear

import android.content.*
import android.os.Bundle
import androidx.wear.widget.WearableActivity
import com.proximityalert.wear.databinding.ActivityWearMainBinding

/**
 * Activity principale sullo smartwatch:
 * mostra lo stato della connessione e reagisce alle allerte
 */
class WearMainActivity : WearableActivity() {

    private lateinit var binding: ActivityWearMainBinding

    private val alertReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                WearListenerService.ACTION_ALERT -> {
                    val distance = intent.getIntExtra(WearListenerService.EXTRA_DISTANCE, 0)
                    showAlert(distance)
                }
                WearListenerService.ACTION_CLEAR -> showNormal()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWearMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setAmbientEnabled()

        showNormal()
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(WearListenerService.ACTION_ALERT)
            addAction(WearListenerService.ACTION_CLEAR)
        }
        registerReceiver(alertReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(alertReceiver)
    }

    private fun showAlert(distance: Int) {
        binding.tvStatus.text = "⚠️ TROPPO\nLONTANO!"
        binding.tvDistance.text = "~${distance}m"
        binding.tvDistance.visibility = android.view.View.VISIBLE
        binding.root.setBackgroundColor(
            resources.getColor(R.color.alert_bg, null))
        binding.tvStatus.setTextColor(
            resources.getColor(R.color.alert_text, null))
    }

    private fun showNormal() {
        binding.tvStatus.text = "🔗 Connesso"
        binding.tvDistance.visibility = android.view.View.GONE
        binding.root.setBackgroundColor(
            resources.getColor(R.color.normal_bg, null))
        binding.tvStatus.setTextColor(
            resources.getColor(R.color.normal_text, null))
    }

    override fun onEnterAmbient(ambientDetails: Bundle?) {
        super.onEnterAmbient(ambientDetails)
        // Modalità ambient: mostra solo testo essenziale
        binding.tvStatus.setTextColor(
            resources.getColor(android.R.color.white, null))
    }
}
